<?php

use Dwes\ORM\Tienda;

include "../eloquent.php";

$tiendas=Tienda::all();
