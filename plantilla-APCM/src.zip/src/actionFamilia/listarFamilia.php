<?php

use Dwes\ORM\Familia;

include "../eloquent.php";

$familias=Familia::all();


